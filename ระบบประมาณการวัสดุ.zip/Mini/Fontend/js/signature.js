let sigCanvas, sigCtx;
let isDrawing = false;
let hasSignature = false;

function initSignaturePad() {
    sigCanvas = document.getElementById('signature-pad');
    if (!sigCanvas) return;
    sigCtx = sigCanvas.getContext('2d');
    
    sigCtx.strokeStyle = '#0f172a';
    sigCtx.lineWidth = 2.5;
    sigCtx.lineCap = 'round';
    sigCtx.lineJoin = 'round';

    // Mouse Event Listeners
    sigCanvas.onmousedown = startDrawing;
    sigCanvas.onmousemove = draw;
    sigCanvas.onmouseup = stopDrawing;
    sigCanvas.onmouseleave = stopDrawing;

    // Touch Event Listeners (Mobile/Tablet)
    sigCanvas.addEventListener('touchstart', (e) => {
        const touch = e.touches[0];
        startDrawing({ clientX: touch.clientX, clientY: touch.clientY });
    }, { passive: true });

    sigCanvas.addEventListener('touchmove', (e) => {
        const touch = e.touches[0];
        draw({ clientX: touch.clientX, clientY: touch.clientY });
        e.preventDefault();
    }, { passive: false });

    sigCanvas.addEventListener('touchend', stopDrawing, { passive: true });
}

function getCanvasPos(e) {
    const rect = sigCanvas.getBoundingClientRect();
    return {
        x: (e.clientX - rect.left) * (sigCanvas.width / rect.width),
        y: (e.clientY - rect.top) * (sigCanvas.height / rect.height)
    };
}

function startDrawing(e) {
    isDrawing = true;
    const pos = getCanvasPos(e);
    sigCtx.beginPath();
    sigCtx.moveTo(pos.x, pos.y);
}

function draw(e) {
    if (!isDrawing) return;
    const pos = getCanvasPos(e);
    sigCtx.lineTo(pos.x, pos.y);
    sigCtx.stroke();
    hasSignature = true;
}

function stopDrawing() {
    isDrawing = false;
}

function clearSignature() {
    if (!sigCtx) return;
    sigCtx.clearRect(0, 0, sigCanvas.width, sigCanvas.height);
    hasSignature = false;
}