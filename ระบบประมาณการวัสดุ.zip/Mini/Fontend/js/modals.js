function openBudgetManageModal() {
    const tbody = document.getElementById('admin-budget-table-body');
    tbody.innerHTML = USERS.map(u => {
        const total = (u.budgetRegular || 0) + (u.budgetSpecial || 0) + (u.budgetOther || 0);
        return `
        <tr class="hover:bg-slate-50 transition border-b border-slate-100">
            <td class="p-2.5">
                <div class="font-bold text-slate-800">${u.name}</div>
                <div class="text-[10px] text-slate-500">${u.department}</div>
            </td>
            <td class="p-2.5">
                <select id="budget-default-type-${u.id}" class="w-full px-2 py-1 bg-slate-50 border border-slate-200 rounded-lg text-xs">
                    <option value="งบประจำปี">งบประจำปี</option>
                    <option value="งบพิเศษ">งบพิเศษ</option>
                    <option value="งบอื่นๆ">งบอื่นๆ</option>
                </select>
            </td>
            <td class="p-2.5 text-right space-y-1">
                <input type="number" step="1000" id="budget-regular-${u.id}" value="${u.budgetRegular || 0}" oninput="calcUserTotalBudget('${u.id}')" class="w-full px-2 py-1 text-right bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold" placeholder="วงเงิน">
                <input type="date" id="deadline-regular-${u.id}" value="${u.deadlineRegular || ''}" class="w-full px-2 py-1 text-center bg-slate-50 border border-slate-200 rounded-lg text-[10px]" title="วันสิ้นสุดการใช้งาน (Deadline)">
            </td>
            <td class="p-2.5 text-right space-y-1">
                <input type="number" step="1000" id="budget-special-${u.id}" value="${u.budgetSpecial || 0}" oninput="calcUserTotalBudget('${u.id}')" class="w-full px-2 py-1 text-right bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold" placeholder="วงเงิน">
                <input type="date" id="deadline-special-${u.id}" value="${u.deadlineSpecial || ''}" class="w-full px-2 py-1 text-center bg-slate-50 border border-slate-200 rounded-lg text-[10px]" title="วันสิ้นสุดการใช้งาน (Deadline)">
            </td>
            <td class="p-2.5 text-right space-y-1">
                <input type="number" step="1000" id="budget-other-${u.id}" value="${u.budgetOther || 0}" oninput="calcUserTotalBudget('${u.id}')" class="w-full px-2 py-1 text-right bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold" placeholder="วงเงิน">
                <input type="date" id="deadline-other-${u.id}" value="${u.deadlineOther || ''}" class="w-full px-2 py-1 text-center bg-slate-50 border border-slate-200 rounded-lg text-[10px]" title="วันสิ้นสุดการใช้งาน (Deadline)">
            </td>
            <td class="p-2.5 text-right font-bold text-purple-700 text-xs" id="budget-total-text-${u.id}">
                ${total.toLocaleString()} บาท
            </td>
            <td class="p-2.5 text-center">
                <button onclick="saveUserBudget('${u.id}')" class="px-3 py-1.5 bg-purple-600 text-white rounded-xl text-xs font-semibold hover:bg-purple-700 shadow-sm transition">
                    <i class="fa-solid fa-floppy-disk"></i> บันทึก
                </button>
            </td>
        </tr>
        `;
    }).join('');
    document.getElementById('admin-budget-modal').classList.remove('hidden');
}

function calcUserTotalBudget(userId) {
    const reg = parseFloat(document.getElementById(`budget-regular-${userId}`).value) || 0;
    const spe = parseFloat(document.getElementById(`budget-special-${userId}`).value) || 0;
    const oth = parseFloat(document.getElementById(`budget-other-${userId}`).value) || 0;
    document.getElementById(`budget-total-text-${userId}`).textContent = `${(reg + spe + oth).toLocaleString()} บาท`;
}

function closeBudgetManageModal() {
    document.getElementById('admin-budget-modal').classList.add('hidden');
    updateUserInterface();
}

function saveUserBudget(userId) {
    const reg = parseFloat(document.getElementById(`budget-regular-${userId}`).value) || 0;
    const dedReg = document.getElementById(`deadline-regular-${userId}`).value;
    const spe = parseFloat(document.getElementById(`budget-special-${userId}`).value) || 0;
    const dedSpe = document.getElementById(`deadline-special-${userId}`).value;
    const oth = parseFloat(document.getElementById(`budget-other-${userId}`).value) || 0;
    const dedOth = document.getElementById(`deadline-other-${userId}`).value;

    const target = USERS.find(u => u.id === userId);
    if (target) {
        target.budgetRegular = reg;
        target.deadlineRegular = dedReg;
        target.budgetSpecial = spe;
        target.deadlineSpecial = dedSpe;
        target.budgetOther = oth;
        target.deadlineOther = dedOth;
        saveUsersBudgetStorage();
        showModal("บันทึกงบประมาณสำเร็จ", `อัปเดต 3 งบประมาณและกำหนดวันสิ้นสุดของ ${target.name} เรียบร้อยแล้ว`, "success");
    }
}

function openAdminAddMaterialModal() { document.getElementById('admin-add-material-modal').classList.remove('hidden'); }
function closeAdminAddMaterialModal() { document.getElementById('admin-add-material-modal').classList.add('hidden'); }

function openMaterialSelectorModal() {
    modalTempSelections = {};
    formSelectedMaterials.forEach(item => { modalTempSelections[item.id] = item.qty; });
    renderModalMaterialList();
    document.getElementById('material-selector-modal').classList.remove('hidden');
}

function closeMaterialSelectorModal() { document.getElementById('material-selector-modal').classList.add('hidden'); }

function renderModalMaterialList() {
    const tbody = document.getElementById('modal-material-list-body');
    const searchVal = document.getElementById('modal-search').value.toLowerCase();
    const catVal = document.getElementById('modal-cat-filter').value;

    const filtered = MATERIAL_ESTIMATES.filter(m => {
        return (m.name.toLowerCase().includes(searchVal)) && (catVal === 'ALL' || m.category === catVal);
    });

    tbody.innerHTML = filtered.map(m => {
        const qty = modalTempSelections[m.id] || 0;
        return `
            <tr class="hover:bg-slate-50">
                <td class="p-2.5 text-center"><input type="checkbox" id="chk-${m.id}" ${qty > 0 ? 'checked' : ''} onchange="toggleModalMaterialSelect('${m.id}')"></td>
                <td class="p-2.5 font-semibold">${m.name}</td>
                <td class="p-2.5 text-[11px] text-slate-500">${m.category}</td>
                <td class="p-2.5 text-center">${m.unit}</td>
                <td class="p-2.5 text-right font-bold text-indigo-600">${m.unitPrice.toLocaleString()}</td>
                <td class="p-2.5 text-center"><input type="number" id="qty-${m.id}" min="1" value="${qty || 1}" oninput="updateModalMaterialQty('${m.id}')" class="w-16 text-center border rounded-lg text-xs"></td>
            </tr>
        `;
    }).join('');
}

function toggleModalMaterialSelect(id) {
    const chk = document.getElementById(`chk-${id}`);
    if (chk.checked) modalTempSelections[id] = parseInt(document.getElementById(`qty-${id}`).value) || 1;
    else delete modalTempSelections[id];
}

function updateModalMaterialQty(id) {
    if (document.getElementById(`chk-${id}`).checked) {
        modalTempSelections[id] = parseInt(document.getElementById(`qty-${id}`).value) || 1;
    }
}

function applySelectedMaterials() {
    formSelectedMaterials = Object.keys(modalTempSelections).map(id => {
        const mat = MATERIAL_ESTIMATES.find(m => m.id === id);
        const qty = modalTempSelections[id];
        return { id: mat.id, name: mat.name, unit: mat.unit, unitPrice: mat.unitPrice, qty: qty, total: mat.unitPrice * qty };
    });
    renderFormSelectedMaterials();
    closeMaterialSelectorModal();
}

function openAdminReviewModal(id) {
    const req = requisitions.find(r => r.id === id);
    if (!req) return;
    document.getElementById('review-req-id').value = req.id;
    document.getElementById('rev-docno').textContent = req.docNo;
    document.getElementById('rev-dept').textContent = req.department;
    document.getElementById('rev-username').textContent = req.userName;
    document.getElementById('rev-budgettype').textContent = req.budgetType || "งบประจำปี";
    document.getElementById('review-status-select').value = req.status === "รอการพิจารณา" ? "อนุมัติ" : req.status;
    document.getElementById('review-comment').value = req.adminComment || "";

    adminEditingItems = JSON.parse(JSON.stringify(req.items));
    renderAdminReviewItems();
    document.getElementById('admin-review-modal').classList.remove('hidden');
}

function renderAdminReviewItems() {
    const tbody = document.getElementById('admin-review-items-body');
    if (adminEditingItems.length === 0) {
        tbody.innerHTML = `<tr><td colspan="6" class="text-center py-4 text-slate-400">ไม่มีรายการวัสดุ</td></tr>`;
        document.getElementById('rev-total-amount').textContent = "0.00";
        return;
    }

    let total = 0;
    tbody.innerHTML = adminEditingItems.map((item, idx) => {
        const itemTotal = (parseFloat(item.unitPrice) || 0) * (parseInt(item.qty) || 0);
        total += itemTotal;
        return `
            <tr class="hover:bg-slate-50">
                <td class="p-2 font-semibold text-slate-800">${item.name}</td>
                <td class="p-2 text-center text-slate-500">${item.unit}</td>
                <td class="p-2 text-right"><input type="number" step="0.01" value="${item.unitPrice}" onchange="updateAdminEditItemPrice(${idx}, this.value)" class="w-20 text-right px-1 py-0.5 border rounded text-xs"></td>
                <td class="p-2 text-center"><input type="number" min="1" value="${item.qty}" onchange="updateAdminEditItemQty(${idx}, this.value)" class="w-16 text-center px-1 py-0.5 border rounded text-xs"></td>
                <td class="p-2 text-right font-bold text-indigo-600">${itemTotal.toLocaleString()}</td>
                <td class="p-2 text-center"><button type="button" onclick="removeAdminEditItem(${idx})" class="text-rose-500 hover:text-rose-700"><i class="fa-solid fa-trash"></i></button></td>
            </tr>
        `;
    }).join('');
    document.getElementById('rev-total-amount').textContent = total.toLocaleString(undefined, {minimumFractionDigits: 2});
}

function updateAdminEditItemPrice(idx, val) {
    adminEditingItems[idx].unitPrice = parseFloat(val) || 0;
    adminEditingItems[idx].total = adminEditingItems[idx].unitPrice * adminEditingItems[idx].qty;
    renderAdminReviewItems();
}

function updateAdminEditItemQty(idx, val) {
    adminEditingItems[idx].qty = parseInt(val) || 1;
    adminEditingItems[idx].total = adminEditingItems[idx].unitPrice * adminEditingItems[idx].qty;
    renderAdminReviewItems();
}

function removeAdminEditItem(idx) {
    adminEditingItems.splice(idx, 1);
    renderAdminReviewItems();
}

function closeAdminReviewModal() { document.getElementById('admin-review-modal').classList.add('hidden'); }

function submitAdminReview() {
    const id = document.getElementById('review-req-id').value;
    const idx = requisitions.findIndex(r => r.id === id);
    if (idx !== -1) {
        if (adminEditingItems.length === 0) {
            showModal("ไม่สามารถบันทึกได้", "ต้องมีรายการวัสดุอย่างน้อย 1 รายการในใบประมาณการ", "error");
            return;
        }

        let totalAmount = 0;
        adminEditingItems.forEach(i => totalAmount += (i.unitPrice * i.qty));

        requisitions[idx].items = adminEditingItems;
        requisitions[idx].itemCount = adminEditingItems.length;
        requisitions[idx].totalAmount = totalAmount;
        requisitions[idx].amountText = ThaiBahtText(totalAmount);
        requisitions[idx].status = document.getElementById('review-status-select').value;
        requisitions[idx].adminComment = document.getElementById('review-comment').value;

        saveStorage();
        closeAdminReviewModal();
        renderRequisitions();
        if (currentUser.role === 'admin') updateAdminNotifications();
        showModal("สำเร็จ", "บันทึกการแก้ไขรายการและผลพิจารณาเรียบร้อยแล้ว", "success");
    }
}

function showModal(title, msg, type = 'success') {
    document.getElementById('modal-title').textContent = title;
    document.getElementById('modal-message').textContent = msg;
    document.getElementById('notification-modal').classList.remove('hidden');
}
function closeModal() { document.getElementById('notification-modal').classList.add('hidden'); }