let MATERIAL_ESTIMATES = [];
let currentUser = null;
let requisitions = [];
let formSelectedMaterials = [];
let modalTempSelections = {};
let adminEditingItems = [];

function initStorage() {
    const savedUsersBudget = localStorage.getItem('ratphum_users_allocated_budgets_v5');
    if (savedUsersBudget) {
        try {
            const budgetMap = JSON.parse(savedUsersBudget);
            USERS.forEach(u => {
                if (budgetMap[u.id]) {
                    u.budgetRegular = budgetMap[u.id].regular || 0;
                    u.deadlineRegular = budgetMap[u.id].deadlineRegular || "2026-09-30";
                    u.budgetSpecial = budgetMap[u.id].special || 0;
                    u.deadlineSpecial = budgetMap[u.id].deadlineSpecial || "2026-08-15";
                    u.budgetOther = budgetMap[u.id].other || 0;
                    u.deadlineOther = budgetMap[u.id].deadlineOther || "2026-12-31";
                }
            });
        } catch (e) {}
    }

    const savedMat = localStorage.getItem('ratphum_master_material_estimates');
    if (savedMat) {
        try { MATERIAL_ESTIMATES = JSON.parse(savedMat); } catch (e) { MATERIAL_ESTIMATES = [...DEFAULT_MATERIAL_ESTIMATES]; }
    } else {
        MATERIAL_ESTIMATES = [...DEFAULT_MATERIAL_ESTIMATES];
        saveMaterialEstimatesStorage();
    }

    const saved = localStorage.getItem('ratphum_estimate_requisitions_v4');
    if (saved) {
        try { requisitions = JSON.parse(saved); } catch (e) { requisitions = []; }
    } else {
        requisitions = [
            {
                id: "REQ-2569-001",
                userId: "user_1",
                userName: "ผู้ช่วยศาสตราจารย์พิเชฐ สุวรรณโณ",
                department: "สาขาวิชาเทคโนโลยีธุรกิจดิจิทัล",
                position: "หัวหน้าสาขาวิชาเทคโนโลยีธุรกิจดิจิทัล",
                docNo: "อว ๐๖๕๕.๒๔/๑",
                docDate: "23 กรกฎาคม 2569",
                academicYear: "2569",
                budgetType: "งบประจำปี",
                itemCount: 2,
                totalAmount: 1093,
                amountText: "(หนึ่งพันเก้าสิบสามบาทถ้วน)",
                notes: "จัดซื้อวัสดุสำนักงาน",
                signature: null,
                items: [
                    { id: "MAT-001", name: "กระดาษ A4 Double A 80 แกรม", unit: "ลัง", unitPrice: 615, qty: 1, total: 615 },
                    { id: "MAT-002", name: "ปากกาไวด์บอร์ด หัวกลม สีน้ำเงิน", unit: "กล่อง", unitPrice: 239, qty: 2, total: 478 }
                ],
                status: "อนุมัติ",
                adminComment: "อนุมัติงบเรียบร้อย",
                createdAt: new Date().toISOString()
            }
        ];
        saveStorage();
    }
}

function saveStorage() {
    localStorage.setItem('ratphum_estimate_requisitions_v4', JSON.stringify(requisitions));
}

function saveUsersBudgetStorage() {
    const budgetMap = {};
    USERS.forEach(u => {
        budgetMap[u.id] = {
            regular: u.budgetRegular, deadlineRegular: u.deadlineRegular,
            special: u.budgetSpecial, deadlineSpecial: u.deadlineSpecial,
            other: u.budgetOther, deadlineOther: u.deadlineOther
        };
    });
    localStorage.setItem('ratphum_users_allocated_budgets_v5', JSON.stringify(budgetMap));
}

function saveMaterialEstimatesStorage() {
    localStorage.setItem('ratphum_master_material_estimates', JSON.stringify(MATERIAL_ESTIMATES));
}

function ThaiBahtText(num) {
    if (!num || isNaN(num) || num <= 0) return "(ศูนย์บาทถ้วน)";
    return `(${num.toLocaleString()} บาทถ้วน)`;
}

function toThaiNum(numStr) {
    if (numStr === null || numStr === undefined) return '';
    const thaiDigits = ['๐', '๑', '๒', '๓', '๔', '๕', '๖', '๗', '๘', '๙'];
    return numStr.toString().replace(/[0-9]/g, x => thaiDigits[x]);
}