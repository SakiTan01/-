function handleLogin(e) {
    e.preventDefault();
    const selectedId = document.getElementById('login-user-select').value;
    const passwordInput = document.getElementById('login-password').value;

    const targetUser = USERS.find(u => u.id === selectedId);
    if (targetUser && targetUser.password === passwordInput) {
        currentUser = targetUser;
        document.getElementById('login-overlay').classList.add('hidden');
        document.getElementById('login-password').value = '';
        updateUserInterface();
        renderRequisitions();
        renderEstimatesTable();
    } else {
        showModal("รหัสผ่านไม่ถูกต้อง", "กรุณาตรวจสอบรหัสผ่านอีกครั้ง (รหัสผ่านเริ่มต้นคือ 123)", "error");
    }
}

function handleLogout() {
    currentUser = null;
    document.getElementById('login-overlay').classList.remove('hidden');
}

function updateUserInterface() {
    if (!currentUser) return;
    document.getElementById('current-user-name').textContent = currentUser.name;
    document.getElementById('current-user-dept').textContent = `${currentUser.position} | ${currentUser.email}`;
    document.getElementById('header-user-name').textContent = currentUser.name;
    document.getElementById('header-user-role').textContent = `[ ${currentUser.roleName} ]`;
    
    const userReqs = requisitions.filter(r => r.userId === currentUser.id && r.status !== "ไม่อนุมัติ");
    
    let usedReg = 0, usedSpec = 0, usedOth = 0;
    userReqs.forEach(r => {
        if (r.budgetType === "งบพิเศษ") usedSpec += r.totalAmount;
        else if (r.budgetType === "งบอื่นๆ") usedOth += r.totalAmount;
        else usedReg += r.totalAmount;
    });

    const remainReg = currentUser.budgetRegular - usedReg;
    const remainSpec = currentUser.budgetSpecial - usedSpec;
    const remainOth = currentUser.budgetOther - usedOth;

    document.getElementById('widget-reg-budget').textContent = `${remainReg.toLocaleString(undefined, {minimumFractionDigits: 2})} / ${currentUser.budgetRegular.toLocaleString()} ฿`;
    document.getElementById('widget-spec-budget').textContent = `${remainSpec.toLocaleString(undefined, {minimumFractionDigits: 2})} / ${currentUser.budgetSpecial.toLocaleString()} ฿`;
    document.getElementById('widget-oth-budget').textContent = `${remainOth.toLocaleString(undefined, {minimumFractionDigits: 2})} / ${currentUser.budgetOther.toLocaleString()} ฿`;

    const badge = document.getElementById('current-user-badge');
    const adminNotifContainer = document.getElementById('admin-notif-container');
    const userFeedbackSection = document.getElementById('user-feedback-section');
    const adminAddMatBtnContainer = document.getElementById('admin-add-material-btn-container');
    const navAdminBudget = document.getElementById('nav-admin-budget');

    if (currentUser.role === 'admin') {
        badge.textContent = "ผู้ดูแลระบบ (Admin)";
        badge.className = "text-xs px-2.5 py-0.5 rounded-full font-semibold bg-amber-100 text-amber-800 border border-amber-200";
        adminNotifContainer.classList.remove('hidden');
        userFeedbackSection.classList.add('hidden');
        if (adminAddMatBtnContainer) adminAddMatBtnContainer.classList.remove('hidden');
        if (navAdminBudget) navAdminBudget.classList.remove('hidden');
        updateAdminNotifications();
    } else {
        badge.textContent = "หัวหน้าสาขาวิชา (User)";
        badge.className = "text-xs px-2.5 py-0.5 rounded-full font-semibold bg-emerald-100 text-emerald-800 border border-emerald-200";
        adminNotifContainer.classList.add('hidden');
        if (adminAddMatBtnContainer) adminAddMatBtnContainer.classList.add('hidden');
        if (navAdminBudget) navAdminBudget.classList.add('hidden');
        updateUserFeedbackNotifications();
    }
}

function updateFormBudgetInfo() {
    if (!currentUser) return;
    const bType = document.getElementById('budget-type-select').value;
    const userReqs = requisitions.filter(r => r.userId === currentUser.id && r.status !== "ไม่อนุมัติ" && r.id !== document.getElementById('edit-id').value);
    
    let totalAllocated = 0;
    let totalUsed = 0;
    let deadlineStr = "";

    if (bType === "งบพิเศษ") {
        totalAllocated = currentUser.budgetSpecial;
        deadlineStr = currentUser.deadlineSpecial;
        userReqs.filter(r => r.budgetType === "งบพิเศษ").forEach(r => totalUsed += r.totalAmount);
    } else if (bType === "งบอื่นๆ") {
        totalAllocated = currentUser.budgetOther;
        deadlineStr = currentUser.deadlineOther;
        userReqs.filter(r => r.budgetType === "งบอื่นๆ").forEach(r => totalUsed += r.totalAmount);
    } else {
        totalAllocated = currentUser.budgetRegular;
        deadlineStr = currentUser.deadlineRegular;
        userReqs.filter(r => !r.budgetType || r.budgetType === "งบประจำปี").forEach(r => totalUsed += r.totalAmount);
    }

    const remain = totalAllocated - totalUsed;
    const hint = document.getElementById('form-budget-remain-hint');
    hint.textContent = `งบนี้ได้รับ ${totalAllocated.toLocaleString()} บาท | คงเหลือเบิกได้: ${remain.toLocaleString(undefined, {minimumFractionDigits: 2})} บาท (หมดเขต: ${deadlineStr || '-'})`;
}

function updateAdminNotifications() {
    const pendingReqs = requisitions.filter(r => r.status === "รอการพิจารณา");
    document.getElementById('admin-notif-badge').textContent = pendingReqs.length;
    document.getElementById('admin-notif-count-text').textContent = `${pendingReqs.length} รายการรอตรวจ`;
    
    const list = document.getElementById('admin-notif-list');
    if (pendingReqs.length === 0) {
        list.innerHTML = `<div class="text-center text-slate-400 py-4">ไม่มีรายการใหม่</div>`;
        return;
    }
    list.innerHTML = pendingReqs.map(r => `
        <div class="p-2 hover:bg-slate-50 rounded-xl cursor-pointer transition" onclick="openAdminReviewModal('${r.id}')">
            <div class="font-bold text-slate-800">${r.department} [${r.budgetType || 'งบประจำปี'}]</div>
            <div class="text-slate-500 text-[10px]">วงเงิน: ${r.totalAmount.toLocaleString()} บาท</div>
        </div>
    `).join('');
}

function toggleAdminNotifDropdown() {
    document.getElementById('admin-notif-dropdown').classList.toggle('hidden');
}

function updateUserFeedbackNotifications() {
    const section = document.getElementById('user-feedback-section');
    const list = document.getElementById('user-feedback-list');
    const myReviewed = requisitions.filter(r => r.userId === currentUser.id && r.status !== "รอการพิจารณา");

    if (myReviewed.length === 0) {
        section.classList.add('hidden');
        return;
    }
    section.classList.remove('hidden');
    list.innerHTML = myReviewed.map(r => `
        <div class="bg-white p-3 rounded-xl border border-amber-100 text-xs flex justify-between items-center">
            <div>
                <div class="font-bold text-slate-800">เลขที่: ${r.docNo} (${r.budgetType || 'งบประจำปี'})</div>
                <div class="text-slate-600">ความเห็น: ${r.adminComment || "ไม่มี"}</div>
            </div>
            <span class="px-3 py-1 rounded-full text-[10px] font-bold ${r.status === 'อนุมัติ' ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'}">${r.status}</span>
        </div>
    `).join('');
}

function switchTab(tabName) {
    document.getElementById('tab-dashboard').classList.add('hidden');
    document.getElementById('tab-estimates').classList.add('hidden');
    document.getElementById('tab-create').classList.add('hidden');
    document.getElementById('tab-print').classList.add('hidden');

    document.getElementById(`tab-${tabName}`).classList.remove('hidden');
    window.scrollTo({ top: 0, behavior: 'smooth' });

    if (tabName === 'dashboard') renderRequisitions();
    else if (tabName === 'estimates') renderEstimatesTable();
}

function handleSaveNewMaterial(e) {
    e.preventDefault();
    const newItem = {
        id: `MAT-${(MATERIAL_ESTIMATES.length + 1).toString().padStart(3, '0')}`,
        name: document.getElementById('new-mat-name').value,
        category: document.getElementById('new-mat-category').value,
        unit: document.getElementById('new-mat-unit').value,
        unitPrice: parseFloat(document.getElementById('new-mat-price').value) || 0
    };
    MATERIAL_ESTIMATES.push(newItem);
    saveMaterialEstimatesStorage();
    closeAdminAddMaterialModal();
    renderEstimatesTable();
    showModal("สำเร็จ", "เพิ่มรายการวัสดุเรียบร้อยแล้ว", "success");
}

function deleteMasterMaterial(id) {
    if (confirm("ต้องการลบรายการนี้?")) {
        MATERIAL_ESTIMATES = MATERIAL_ESTIMATES.filter(m => m.id !== id);
        saveMaterialEstimatesStorage();
        renderEstimatesTable();
    }
}

function updateMaterialPrice(id, newPrice) {
    const price = parseFloat(newPrice);
    if (isNaN(price) || price < 0) {
        showModal("กรุณากรอกราคาให้ถูกต้อง", "ราคาต่อหน่วยต้องเป็นตัวเลขที่ไม่ติดลบ", "error");
        renderEstimatesTable();
        return;
    }
    const item = MATERIAL_ESTIMATES.find(m => m.id === id);
    if (item) {
        item.unitPrice = price;
        saveMaterialEstimatesStorage();
        showModal("สำเร็จ", `อัปเดตราคาของ "${item.name}" เป็น ${price.toLocaleString()} บาท เรียบร้อยแล้ว`, "success");
    }
}

function renderEstimatesTable() {
    const tbody = document.getElementById('estimates-table-body');
    const filterCat = document.getElementById('estimate-category-filter').value;
    const searchVal = document.getElementById('estimate-search-input').value.toLowerCase();
    
    const items = MATERIAL_ESTIMATES.filter(m => {
        const matchCat = filterCat === 'ALL' || m.category === filterCat;
        const matchSearch = m.name.toLowerCase().includes(searchVal);
        return matchCat && matchSearch;
    });

    const isAdmin = currentUser && currentUser.role === 'admin';
    document.getElementById('admin-col-action-header').classList.toggle('hidden', !isAdmin);

    tbody.innerHTML = items.map((m, idx) => `
        <tr class="hover:bg-slate-50 transition">
            <td class="p-3 text-center text-slate-400">${idx + 1}</td>
            <td class="p-3 font-semibold text-slate-800">${m.name}</td>
            <td class="p-3"><span class="px-2 py-0.5 bg-slate-100 rounded-full text-[11px]">${m.category}</span></td>
            <td class="p-3 text-center">${m.unit}</td>
            <td class="p-3 text-right">
                ${isAdmin ? `<input type="number" step="0.01" min="0" value="${m.unitPrice}" onchange="updateMaterialPrice('${m.id}', this.value)" class="w-32 px-2 py-1 text-right bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold text-indigo-600 focus:ring-2 focus:ring-indigo-500">` : `<span class="font-bold text-indigo-600">${m.unitPrice.toLocaleString()} บาท</span>`}
            </td>
            ${isAdmin ? `<td class="p-3 text-center"><button onclick="deleteMasterMaterial('${m.id}')" class="text-rose-600 hover:text-rose-800" title="ลบรายการ"><i class="fa-solid fa-trash-can"></i></button></td>` : ''}
        </tr>
    `).join('');
}

function renderFormSelectedMaterials() {
    const tbody = document.getElementById('selected-materials-body');
    if (formSelectedMaterials.length === 0) {
        tbody.innerHTML = `<tr><td colspan="7" class="text-center py-6 text-slate-400">ยังไม่ได้เลือกรายการวัสดุ</td></tr>`;
        document.getElementById('item-count').value = 0;
        document.getElementById('total-amount').value = 0;
        document.getElementById('amount-text').value = "(ศูนย์บาทถ้วน)";
        return;
    }

    let grandTotal = 0;
    tbody.innerHTML = formSelectedMaterials.map((item, idx) => {
        grandTotal += item.total;
        return `
            <tr>
                <td class="p-2.5 text-center">${idx + 1}</td>
                <td class="p-2.5 font-semibold">${item.name}</td>
                <td class="p-2.5 text-center">${item.unit}</td>
                <td class="p-2.5 text-right">${item.unitPrice.toLocaleString()}</td>
                <td class="p-2.5 text-center"><input type="number" value="${item.qty}" onchange="changeFormItemQty('${item.id}', this.value)" class="w-16 text-center border rounded"></td>
                <td class="p-2.5 text-right font-bold text-indigo-600">${item.total.toLocaleString()}</td>
                <td class="p-2.5 text-center"><button type="button" onclick="removeFormItem('${item.id}')" class="text-rose-500"><i class="fa-solid fa-trash"></i></button></td>
            </tr>
        `;
    }).join('');

    document.getElementById('item-count').value = formSelectedMaterials.length;
    document.getElementById('total-amount').value = grandTotal;
    document.getElementById('amount-text').value = ThaiBahtText(grandTotal);
}

function changeFormItemQty(id, qty) {
    const item = formSelectedMaterials.find(m => m.id === id);
    if (item) {
        item.qty = parseInt(qty) || 1;
        item.total = item.unitPrice * item.qty;
        renderFormSelectedMaterials();
    }
}

function removeFormItem(id) {
    formSelectedMaterials = formSelectedMaterials.filter(m => m.id !== id);
    renderFormSelectedMaterials();
}

function openCreateForm(editId = null) {
    document.getElementById('memo-form').reset();
    document.getElementById('edit-id').value = '';
    formSelectedMaterials = [];

    switchTab('create');

    setTimeout(() => {
        initSignaturePad();
        clearSignature();

        if (editId) {
            const req = requisitions.find(r => r.id === editId);
            if (req) {
                document.getElementById('edit-id').value = req.id;
                document.getElementById('dept-input').value = req.department;
                document.getElementById('doc-no').value = req.docNo;
                document.getElementById('doc-date').value = req.docDate;
                document.getElementById('academic-year').value = req.academicYear;
                document.getElementById('budget-type-select').value = req.budgetType || "งบประจำปี";
                document.getElementById('memo-notes').value = req.notes || '';
                formSelectedMaterials = JSON.parse(JSON.stringify(req.items));

                if (req.signature) {
                    const img = new Image();
                    img.onload = function() {
                        sigCtx.drawImage(img, 0, 0);
                        hasSignature = true;
                    };
                    img.src = req.signature;
                }
            }
        } else {
            document.getElementById('dept-input').value = currentUser.department;
            document.getElementById('doc-no').value = "อว ๐๖๕๕.๒๔/";
            document.getElementById('doc-date').value = "23 กรกฎาคม 2569";
            document.getElementById('academic-year').value = "2569";
            document.getElementById('budget-type-select').value = "งบประจำปี";
        }
        updateFormBudgetInfo();
        renderFormSelectedMaterials();
    }, 100);
}

function handleFormSubmit(e) {
    e.preventDefault();
    if (formSelectedMaterials.length === 0) {
        showModal("กรุณาเลือกรายการ", "โปรดเลือกรายการวัสดุอย่างน้อย 1 รายการ", "error");
        return;
    }

    const totalAmount = parseFloat(document.getElementById('total-amount').value) || 0;
    const budgetType = document.getElementById('budget-type-select').value;
    const editId = document.getElementById('edit-id').value;

    const todayStr = new Date().toISOString().split('T')[0];
    let deadlineCheck = "";
    if (budgetType === "งบพิเศษ") deadlineCheck = currentUser.deadlineSpecial;
    else if (budgetType === "งบอื่นๆ") deadlineCheck = currentUser.deadlineOther;
    else deadlineCheck = currentUser.deadlineRegular;

    if (deadlineCheck && todayStr > deadlineCheck) {
        showModal("เลยกำหนดวันสิ้นสุดการใช้งานงบประมาณ", `ไม่สามารถเบิกจ่ายได้ เนื่องจาก ${budgetType} หมดเขตการใช้งานตั้งแต่วันที่ ${deadlineCheck} แล้ว`, "error");
        return;
    }

    if (currentUser.role !== 'admin') {
        const userReqs = requisitions.filter(r => r.userId === currentUser.id && r.status !== "ไม่อนุมัติ" && r.id !== editId);
        let allocated = 0, used = 0;
        
        if (budgetType === "งบพิเศษ") {
            allocated = currentUser.budgetSpecial;
            userReqs.filter(r => r.budgetType === "งบพิเศษ").forEach(r => used += r.totalAmount);
        } else if (budgetType === "งบอื่นๆ") {
            allocated = currentUser.budgetOther;
            userReqs.filter(r => r.budgetType === "งบอื่นๆ").forEach(r => used += r.totalAmount);
        } else {
            allocated = currentUser.budgetRegular;
            userReqs.filter(r => !r.budgetType || r.budgetType === "งบประจำปี").forEach(r => used += r.totalAmount);
        }

        if (totalAmount > (allocated - used)) {
            showModal("งบประมาณไม่เพียงพอ", `วงเงินขอเบิก (${totalAmount.toLocaleString()} บาท) เกินกว่ายอดคงเหลือของ ${budgetType}`, "error");
            return;
        }
    }

    const signatureData = hasSignature ? sigCanvas.toDataURL('image/png') : null;

    const data = {
        id: editId || `REQ-${Date.now()}`,
        userId: currentUser.id,
        userName: currentUser.name,
        department: document.getElementById('dept-input').value,
        position: currentUser.position,
        docNo: document.getElementById('doc-no').value,
        docDate: document.getElementById('doc-date').value,
        academicYear: document.getElementById('academic-year').value,
        budgetType: budgetType,
        itemCount: formSelectedMaterials.length,
        totalAmount: totalAmount,
        amountText: document.getElementById('amount-text').value,
        notes: document.getElementById('memo-notes').value,
        signature: signatureData,
        items: formSelectedMaterials,
        status: "รอการพิจารณา",
        adminComment: "",
        createdAt: new Date().toISOString()
    };

    if (editId) {
        const idx = requisitions.findIndex(r => r.id === editId);
        if (idx !== -1) {
            data.status = requisitions[idx].status;
            requisitions[idx] = data;
        }
    } else {
        requisitions.unshift(data);
    }

    saveStorage();
    showModal("สำเร็จ", "บันทึกและส่งข้อมูลไปยังแอดมินเรียบร้อยแล้ว", "success");
    switchTab('dashboard');
}

function deleteRequisition(id) {
    if (confirm("ต้องการลบรายการนี้?")) {
        requisitions = requisitions.filter(r => r.id !== id);
        saveStorage();
        renderRequisitions();
    }
}

function viewPrintMemo(id) {
    const req = requisitions.find(r => r.id === id);
    if (!req) return;

    // อัปเดต บันทึกข้อความ (แปลงเป็นตัวเลขไทย)
    document.getElementById('print-dept').textContent = `วิทยาลัยรัตภูมิ มหาวิทยาลัยเทคโนโลยีราชมงคลศรีวิชัย`;
    document.getElementById('print-docno').textContent = req.docNo;
    document.getElementById('print-date').textContent = req.docDate;
    document.getElementById('print-budgettype-body').textContent = req.budgetType || "งบประจำปี";
    document.getElementById('print-academicyear-body').textContent = toThaiNum(req.academicYear);
    document.getElementById('print-dept-body').textContent = req.department;
    document.getElementById('print-itemcount').textContent = toThaiNum(req.itemCount);
    document.getElementById('print-totalamount').textContent = toThaiNum(req.totalAmount.toLocaleString());
    document.getElementById('print-amounttext').textContent = req.amountText;
    document.getElementById('print-sign-name').textContent = req.userName;
    document.getElementById('print-sign-position').textContent = req.position;

    // อัปเดต ใบประมาณการวัสดุ
    document.getElementById('est-print-dept').textContent = req.department;
    document.getElementById('est-print-itemcount').textContent = toThaiNum(req.itemCount);
    document.getElementById('est-print-academicyear').textContent = toThaiNum(req.academicYear);
    document.getElementById('est-print-sign-name').textContent = req.userName;
    document.getElementById('est-print-sign-name2').textContent = req.userName;
    document.getElementById('est-print-totalamount').textContent = toThaiNum(req.totalAmount.toLocaleString());

    // จัดการภาพลายเซ็นบันทึกข้อความ & ใบประมาณการ
    const printSigImg = document.getElementById('print-sig-img');
    const printSigDots = document.getElementById('print-sig-dots');
    const estSigImg = document.getElementById('est-print-sig-img');
    const estSigDots = document.getElementById('est-print-sig-dots');

    if (req.signature) {
        printSigImg.src = req.signature;
        printSigImg.classList.remove('hidden');
        printSigDots.classList.add('hidden');

        estSigImg.src = req.signature;
        estSigImg.classList.remove('hidden');
        estSigDots.classList.add('hidden');
    } else {
        printSigImg.classList.add('hidden');
        printSigDots.classList.remove('hidden');

        estSigImg.classList.add('hidden');
        estSigDots.classList.remove('hidden');
    }

    document.getElementById('est-print-items-body').innerHTML = req.items.map((item, i) => `
        <tr>
            <td class="border border-black p-1 text-center">${toThaiNum(i + 1)}</td>
            <td class="border border-black p-1">${item.name}</td>
            <td class="border border-black p-1 text-center w-10">${toThaiNum(item.qty)}</td>
            <td class="border border-black p-1 text-center w-12">${item.unit}</td>
            <td class="border border-black p-1 text-right">${toThaiNum(item.unitPrice.toLocaleString())}</td>
            <td class="border border-black p-1 text-right">${toThaiNum(item.total.toLocaleString())}</td>
            <td class="border border-black p-1 text-center"></td>
            <td class="border border-black p-1 text-center"></td>
        </tr>
    `).join('');

    switchTab('print');
}

function renderRequisitions() {
    if (!currentUser) return;
    const tbody = document.getElementById('requisitions-table-body');
    const searchVal = document.getElementById('search-input').value.toLowerCase();
    
    let filtered = requisitions.filter(r => {
        const match = r.docNo.toLowerCase().includes(searchVal) || r.department.toLowerCase().includes(searchVal);
        return currentUser.role === 'admin' ? match : match && r.userId === currentUser.id;
    });

    document.getElementById('count-total').textContent = filtered.length;
    document.getElementById('empty-state').classList.toggle('hidden', filtered.length > 0);

    tbody.innerHTML = filtered.map(r => `
        <tr class="hover:bg-slate-50">
            <td class="p-3"><strong>${r.docNo}</strong><br><span class="text-[11px] text-slate-400">${r.docDate}</span></td>
            <td class="p-3">${r.department}<br><span class="text-[11px] text-slate-500">${r.userName}</span></td>
            <td class="p-3"><span class="px-2 py-0.5 bg-indigo-50 text-indigo-700 rounded-md font-semibold text-[11px]">${r.budgetType || 'งบประจำปี'}</span></td>
            <td class="p-3">${r.academicYear}</td>
            <td class="p-3 text-right">${r.itemCount} รายการ</td>
            <td class="p-3 text-right font-bold text-indigo-600">${r.totalAmount.toLocaleString()}</td>
            <td class="p-3 text-center"><span class="px-2.5 py-1 rounded-full text-[10px] font-bold ${r.status === 'อนุมัติ' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}">${r.status}</span></td>
            <td class="p-3 text-center flex justify-center gap-1">
                <button onclick="viewPrintMemo('${r.id}')" class="px-2 py-1 bg-emerald-50 text-emerald-600 rounded-lg text-xs"><i class="fa-solid fa-print"></i> พิมพ์</button>
                ${currentUser.role === 'admin' ? `<button onclick="openAdminReviewModal('${r.id}')" class="p-1.5 bg-indigo-50 text-indigo-600 rounded-lg" title="ตรวจและแก้ไขรายการ"><i class="fa-solid fa-list-check"></i></button>` : ''}
                <button onclick="openCreateForm('${r.id}')" class="p-1.5 bg-amber-50 text-amber-600 rounded-lg" title="แก้ไขเอกสาร"><i class="fa-solid fa-pen-to-square"></i></button>
                <button onclick="deleteRequisition('${r.id}')" class="p-1.5 bg-rose-50 text-rose-600 rounded-lg" title="ลบ"><i class="fa-solid fa-trash"></i></button>
            </td>
        </tr>
    `).join('');
}