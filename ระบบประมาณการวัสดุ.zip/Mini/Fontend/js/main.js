function initLoginSelect() {
    const select = document.getElementById('login-user-select');
    if (!select) return;
    select.innerHTML = '';
    USERS.forEach(u => {
        const opt = document.createElement('option');
        opt.value = u.id;
        opt.textContent = `[${u.roleName}] ${u.name} (${u.department})`;
        select.appendChild(opt);
    });
}

window.onload = function() {
    initStorage();
    initLoginSelect();
};