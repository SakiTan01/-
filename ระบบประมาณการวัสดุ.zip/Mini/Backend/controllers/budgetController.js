const db = require('../config/db');

// ดึงโควต้างบประมาณและ Deadline ทั้งหมด
exports.getBudgets = async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT u.id, u.name, u.department, 
             b.budget_regular AS budgetRegular, b.deadline_regular AS deadlineRegular,
             b.budget_special AS budgetSpecial, b.deadline_special AS deadlineSpecial,
             b.budget_other AS budgetOther, b.deadline_other AS deadlineOther
      FROM users u
      LEFT JOIN user_budgets b ON u.id = b.user_id
    `);
    res.json({ success: true, data: rows });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// อัปเดตโควต้างบประมาณและ Deadline ของสาขา
exports.updateBudget = async (req, res) => {
  try {
    const { userId } = req.params;
    const {
      budgetRegular, deadlineRegular,
      budgetSpecial, deadlineSpecial,
      budgetOther, deadlineOther
    } = req.body;

    const sql = `
      INSERT INTO user_budgets (user_id, budget_regular, deadline_regular, budget_special, deadline_special, budget_other, deadline_other)
      VALUES (?, ?, ?, ?, ?, ?, ?)
      ON DUPLICATE KEY UPDATE
        budget_regular = VALUES(budget_regular), deadline_regular = VALUES(deadline_regular),
        budget_special = VALUES(budget_special), deadline_special = VALUES(deadline_special),
        budget_other = VALUES(budget_other), deadline_other = VALUES(deadline_other)
    `;

    await db.query(sql, [userId, budgetRegular, deadlineRegular, budgetSpecial, deadlineSpecial, budgetOther, deadlineOther]);
    res.json({ success: true, message: 'อัปเดตงบประมาณเรียบร้อยแล้ว' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};