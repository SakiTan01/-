const db = require('../config/db');

// ดึงรายการคลังวัสดุทั้งหมดจาก MySQL
exports.getMaterials = async (req, res) => {
  try {
    const { search, category } = req.query;
    let sql = 'SELECT id, name, category, unit, unit_price AS unitPrice FROM materials WHERE 1=1';
    const params = [];

    if (category && category !== 'ALL') {
      sql += ' AND category = ?';
      params.push(category);
    }
    if (search) {
      sql += ' AND name LIKE ?';
      params.push(`%${search}%`);
    }

    const [rows] = await db.query(sql, params);
    res.json({ success: true, data: rows });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// เพิ่มรายการวัสดุใหม่
exports.addMaterial = async (req, res) => {
  try {
    const { name, category, unit, unitPrice } = req.body;
    const [countRow] = await db.query('SELECT COUNT(*) as total FROM materials');
    const newId = `MAT-${(countRow[0].total + 1).toString().padStart(3, '0')}`;

    const sql = 'INSERT INTO materials (id, name, category, unit, unit_price) VALUES (?, ?, ?, ?, ?)';
    await db.query(sql, [newId, name, category, unit, unitPrice]);

    res.status(201).json({ success: true, data: { id: newId, name, category, unit, unitPrice } });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};