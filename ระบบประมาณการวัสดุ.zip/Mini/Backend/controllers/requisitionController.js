const db = require('../config/db');

// 1. ดึงรายการใบประมาณการทั้งหมด (หรือแยกตาม User)
exports.getRequisitions = async (req, res) => {
  try {
    const { userId, role } = req.query;
    let sql = 'SELECT * FROM requisitions ORDER BY created_at DESC';
    let params = [];

    if (role !== 'admin' && userId) {
      sql = 'SELECT * FROM requisitions WHERE user_id = ? ORDER BY created_at DESC';
      params.push(userId);
    }

    const [reqs] = await db.query(sql, params);

    // ดึงรายการวัสดุย่อยของแต่ละใบประมาณการ
    for (let r of reqs) {
      const [items] = await db.query('SELECT material_id AS id, name, unit, unit_price AS unitPrice, qty, total FROM requisition_items WHERE requisition_id = ?', [r.id]);
      r.items = items;
    }

    res.json({ success: true, data: reqs });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// 2. สร้างใบประมาณการและบันทึกข้อความใหม่ (มี Transaction)
exports.createRequisition = async (req, res) => {
  const connection = await db.getConnection();
  try {
    await connection.beginTransaction();

    const {
      userId, userName, department, position, docNo, docDate,
      academicYear, budgetType, items, totalAmount, amountText, notes, signature
    } = req.body;

    const reqId = `REQ-${Date.now()}`;

    // บันทึกหัวข้อใบประมาณการ
    const insertReqSql = `
      INSERT INTO requisitions (id, user_id, user_name, department, position, doc_no, doc_date, academic_year, budget_type, item_count, total_amount, amount_text, notes, signature)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;
    await connection.query(insertReqSql, [
      reqId, userId, userName, department, position, docNo, docDate,
      academicYear, budgetType, items.length, totalAmount, amountText, notes, signature
    ]);

    // บันทึกรายการวัสดุย่อย
    const insertItemSql = `
      INSERT INTO requisition_items (requisition_id, material_id, name, unit, unit_price, qty, total)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `;
    for (let item of items) {
      await connection.query(insertItemSql, [
        reqId, item.id, item.name, item.unit, item.unitPrice, item.qty, item.total
      ]);
    }

    await connection.commit();
    res.status(201).json({ success: true, message: 'บันทึกคำขอจัดซื้อเรียบร้อยแล้ว', data: { id: reqId } });
  } catch (error) {
    await connection.rollback();
    res.status(500).json({ success: false, message: error.message });
  } finally {
    connection.release();
  }
};

// 3. แอดมินพิจารณาอนุมัติ/ไม่อนุมัติ หรือแก้ไขรายการ
exports.reviewRequisition = async (req, res) => {
  const connection = await db.getConnection();
  try {
    await connection.beginTransaction();

    const { id } = req.params;
    const { status, adminComment, items, totalAmount, amountText } = req.body;

    // อัปเดตสถานะและข้อมูลหลัก
    const updateReqSql = `
      UPDATE requisitions 
      SET status = ?, admin_comment = ?, item_count = ?, total_amount = ?, amount_text = ?
      WHERE id = ?
    `;
    await connection.query(updateReqSql, [status, adminComment, items.length, totalAmount, amountText, id]);

    // ลบรายการวัสดุเดิมออกแล้วลงรายการใหม่
    await connection.query('DELETE FROM requisition_items WHERE requisition_id = ?', [id]);

    const insertItemSql = `
      INSERT INTO requisition_items (requisition_id, material_id, name, unit, unit_price, qty, total)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `;
    for (let item of items) {
      await connection.query(insertItemSql, [
        id, item.id, item.name, item.unit, item.unitPrice, item.qty, item.total
      ]);
    }

    await connection.commit();
    res.json({ success: true, message: 'อัปเดตผลการพิจารณาเรียบร้อยแล้ว' });
  } catch (error) {
    await connection.rollback();
    res.status(500).json({ success: false, message: error.message });
  } finally {
    connection.release();
  }
};

// 4. ลบใบประมาณการ
exports.deleteRequisition = async (req, res) => {
  try {
    const { id } = req.params;
    await db.query('DELETE FROM requisitions WHERE id = ?', [id]);
    res.json({ success: true, message: 'ลบรายการสำเร็จ' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const { sendEmail } = require('../utils/mailer');

// ตัวอย่างฟังก์ชันสร้างใบประมาณการ
exports.createRequisition = async (req, res) => {
    try {
        // ... โค้ดบันทึกข้อมูลลงฐานข้อมูล MySQL ของคุณปกติ ...

        // หลังจากบันทึกสำเร็จ ส่งอีเมลหา Admin ทันที
        await sendEmail(
            'dhmgamer12@gmail.com',
            `[แจ้งเตือนคำขอใหม่] เลขที่ ${req.body.doc_no} จาก ${req.body.dept}`,
            `เรียน แอดมิน,\n\nมีคำขอจัดซื้อวัสดุใหม่ เลขที่ ${req.body.doc_no}\nจากหน่วยงาน: ${req.body.dept}\nวงเงินรวม: ${req.body.total_amount} บาท\n\nกรุณาตรวจสอบระบบเพื่อพิจารณาอนุมัติ`
        );

        res.status(201).json({ success: true, message: 'สร้างคำขอสำเร็จและส่งเมลหาแอดมินแล้ว' });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
};

// ตัวอย่างฟังก์ชันอัปเดตสถานะของ Admin
exports.updateRequisitionStatus = async (req, res) => {
    try {
        const { status, admin_comment, user_email } = req.body; // user_email คืออีเมลของ User เช่น nitipumkeadkumpong@gmail.com

        // ... โค้ดอัปเดตสถานะลง MySQL ปกติ ...

        // ส่งอีเมลแจ้งผลไปหา User
        await sendEmail(
            user_email,
            `[ผลการพิจารณาคำขอ] เอกสารสถานะ: ${status}`,
            `เรียน ผู้ใช้งาน,\n\nคำขอจัดซื้อวัสดุของท่าน ${status}\nหมายเหตุจากแอดมิน: ${admin_comment || '-'}\n\nคุณสามารถตรวจสอบรายละเอียดเพิ่มเติมได้ในระบบ`
        );

        res.status(200).json({ success: true, message: 'อัปเดตสถานะและส่งเมลแจ้ง User สำเร็จ' });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
};