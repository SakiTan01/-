const db = require('../config/db');

// ดึงรายชื่อผู้ใช้ทั้งหมดจาก MySQL
exports.getUsers = async (req, res) => {
  try {
    const [rows] = await db.query('SELECT id, name, email, role, department, position FROM users');
    res.json({ success: true, data: rows });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// ตรวจสอบการเข้าสู่ระบบ
exports.login = async (req, res) => {
  try {
    const { userId, password } = req.body;
    const [rows] = await db.query('SELECT * FROM users WHERE id = ? AND password = ?', [userId, password]);

    if (rows.length === 0) {
      return res.status(401).json({ success: false, message: 'รหัสผ่านไม่ถูกต้อง' });
    }

    const { password: _, ...userData } = rows[0];
    res.json({ success: true, user: userData, token: 'mock-jwt-token-xxxx' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};