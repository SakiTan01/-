const mongoose = require('mongoose');

const requisitionSchema = new mongoose.Schema({
    doc_no: { type: String, required: true },
    dept: { type: String, required: true },
    doc_date: { type: String, required: true },
    academic_year: { type: String, required: true },
    budget_type: { type: String, required: true },
    budget_purpose: { type: String },
    item_count: { type: Number, required: true },
    total_amount: { type: Number, required: true },
    amount_text: { type: String, required: true },
    memo_notes: { type: String },
    user_email: { type: String, required: true },
    status: { type: String, default: 'รอแอดมินตรวจสอบ' },
    admin_comment: { type: String },
    items: [
        {
            item_name: String,
            unit: String,
            unit_price: Number,
            quantity: Number,
            total_price: Number
        }
    ],
    created_at: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Requisition', requisitionSchema);