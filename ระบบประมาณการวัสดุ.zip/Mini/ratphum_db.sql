-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Generation Time: Oct 22, 2026 at 04:15 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ratphum_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `materials`
--

CREATE TABLE `materials` (
  `id` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `unit` varchar(50) NOT NULL,
  `unitPrice` decimal(10,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `requisitions`
--

CREATE TABLE `requisitions` (
  `id` varchar(50) NOT NULL,
  `userId` varchar(50) NOT NULL,
  `userName` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `docNo` varchar(100) NOT NULL,
  `docDate` varchar(100) NOT NULL,
  `academicYear` varchar(20) NOT NULL,
  `budgetType` varchar(50) NOT NULL DEFAULT 'งบประจำปี',
  `itemCount` int(11) NOT NULL DEFAULT 0,
  `totalAmount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `amountText` varchar(255) NOT NULL,
  `notes` text DEFAULT NULL,
  `signature` longtext DEFAULT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'รอการพิจารณา',
  `adminComment` text DEFAULT NULL,
  `createdAt` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `requisition_items`
--

CREATE TABLE `requisition_items` (
  `id` int(11) NOT NULL,
  `requisitionId` varchar(50) NOT NULL,
  `materialId` varchar(50) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `unit` varchar(50) NOT NULL,
  `unitPrice` decimal(10,2) NOT NULL,
  `qty` int(11) NOT NULL,
  `total` decimal(12,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `role` varchar(50) NOT NULL DEFAULT 'user',
  `roleName` varchar(100) NOT NULL,
  `department` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL DEFAULT '123',
  `budgetRegular` decimal(12,2) DEFAULT 30000.00,
  `deadlineRegular` date DEFAULT '2026-09-30',
  `budgetSpecial` decimal(12,2) DEFAULT 15000.00,
  `deadlineSpecial` date DEFAULT '2026-08-15',
  `budgetOther` decimal(12,2) DEFAULT 5000.00,
  `deadlineOther` date DEFAULT '2026-12-31'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `role`, `roleName`, `department`, `position`, `password`, `budgetRegular`, `deadlineRegular`, `budgetSpecial`, `deadlineSpecial`, `budgetOther`, `deadlineOther`) VALUES
('admin_1', 'นางสาวมัญชรี ศรีจำลอง', 'muncharee.s@rmutsv.ac.th', 'admin', 'เจ้าหน้าที่', 'สำนักงานผู้อำนวยการ / งานพัสดุ', 'เจ้าหน้าที่', '123', 300000.00, '2026-09-30', 150000.00, '2026-08-15', 50000.00, '2026-12-31'),
('user_1', 'ผู้ช่วยศาสตราจารย์พิเชฐ สุวรรณโณ', 'pichet.s@rmutsv.ac.th', 'user', 'หัวหน้าสาขาวิชา', 'สาขาวิชาเทคโนโลยีธุรกิจดิจิทัล', 'หัวหน้าสาขาวิชาเทคโนโลยีธุรกิจดิจิทัล', '123', 30000.00, '2026-09-30', 15000.00, '2026-08-15', 5000.00, '2026-12-31'),
('user_2', 'อาจารย์อำมรรัตน์ คงกะโชติ', 'ammonrat.r@rmutsv.ac.th', 'user', 'หัวหน้าสาขาวิชา', 'สาขาวิชาการบัญชี', 'หัวหน้าสาขาวิชาการบัญชี', '123', 30000.00, '2026-09-30', 15000.00, '2026-08-15', 5000.00, '2026-12-31'),
('user_3', 'อาจารย์ณัฐิรงค์ กฤตานนท์', 'nuttirong.k@rmusv.ac.th', 'user', 'หัวหน้าสาขาวิชา', 'สาขาวิชาการตลาดดิจิทัล', 'หัวหน้าสาขาวิชาการตลาดดิจิทัล', '123', 30000.00, '2026-09-30', 15000.00, '2026-08-15', 5000.00, '2026-12-31'),
('user_4', 'อาจารย์คฑาวุธ ชุมขวัญ', 'katawoot.ch@rmusv.ac.th', 'user', 'หัวหน้าสาขาวิชา', 'สาขาวิชาช่างไฟฟ้า', 'หัวหน้าสาขาวิชาช่างไฟฟ้า', '123', 30000.00, '2026-09-30', 15000.00, '2026-08-15', 5000.00, '2026-12-31'),
('user_5', 'ผู้ช่วยศาสตราจารย์ประชิต พรหมสุวรรณ', 'prachit.@rmutsv.ac.th', 'user', 'หัวหน้าสาขาวิชา', 'สาขาวิชาช่างยนต์', 'หัวหน้าสาขาวิชาช่างยนต์', '123', 30000.00, '2026-09-30', 15000.00, '2026-08-15', 5000.00, '2026-12-31'),
('user_6', 'ผู้ช่วยศาสตราจารย์เพ็ญนภา เชาวนา', 'pennapa.c@rmutsv.ac.th', 'user', 'หัวหน้าสาขาวิชา', 'สาขาวิชาการบัญชีบัณฑิต', 'หัวหน้าสาขาวิชาการบัญชีบัณฑิต', '123', 30000.00, '2026-09-30', 15000.00, '2026-08-15', 5000.00, '2026-12-31'),
('user_7', 'ผู้ช่วยศาสตราจารย์วันประชา นวนสร้อย', 'wanpracha.n@rmusv.ac.th', 'user', 'หัวหน้าสาขาวิชา', 'สาขาวิศวกรรมปัญญาประดิษฐ์ประยุกต์', 'หัวหน้าสาขาวิศวกรรมปัญญาประดิษฐ์ประยุกต์', '123', 30000.00, '2026-09-30', 15000.00, '2026-08-15', 5000.00, '2026-12-31'),
('user_8', 'ผู้ช่วยศาสตราจารย์ธนะวิทย์ ทองวิเชียร', 'tanawit.t@rmusv.ac.th', 'user', 'หัวหน้าสาขาวิชา', 'สาขาวิชาวิศวกรรมเครื่องจักรกลเกษตร', 'หัวหน้าสาขาวิชาวิศวกรรมเครื่องจักรกลเกษตร', '123', 30000.00, '2026-09-30', 15000.00, '2026-08-15', 5000.00, '2026-12-31'),
('user_9', 'ผู้ช่วยศาสตราจารย์ศิวดล นวลนภดล', 'sivadol.n@rmutsv.ac.th', 'user', 'หัวหน้าสาขาวิชา', 'สาขาวิชาวิศวกรรมไฟฟ้า', 'หัวหน้าสาขาวิชาวิศวกรรมไฟฟ้า', '123', 30000.00, '2026-09-30', 15000.00, '2026-08-15', 5000.00, '2026-12-31');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `materials`
--
ALTER TABLE `materials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `requisitions`
--
ALTER TABLE `requisitions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `requisition_items`
--
ALTER TABLE `requisition_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `requisitionId` (`requisitionId`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `requisition_items`
--
ALTER TABLE `requisition_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `requisition_items`
--
ALTER TABLE `requisition_items`
  ADD CONSTRAINT `requisition_items_ibfk_1` FOREIGN KEY (`requisitionId`) REFERENCES `requisitions` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
